#ifndef ARDUINO_CONTROLLER_H
#define ARDUINO_CONTROLLER_H

#include <stdbool.h>

typedef struct {
    bool left;
    bool right;
    bool jump;
    bool attack;
    bool down;
    int score;
    int game_time;
    int game_state;
} ArduinoController;

void arduino_controller_init();
void arduino_controller_update();
void arduino_controller_close();
const ArduinoController* arduino_controller_get_state();

#endif
