#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "fonctions.h"

static TTF_Font *font = NULL;

int initSDL(SDL_Surface **screen) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0) {
        fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());
        return -1;
    }
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        fprintf(stderr, "IMG_Init: %s\n", IMG_GetError());
        return -1;
    }
    if (TTF_Init() == -1) {
        fprintf(stderr, "TTF_Init: %s\n", TTF_GetError());
        return -1;
    }
    *screen = SDL_SetVideoMode(800, 600, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    if (!*screen) {
        fprintf(stderr, "SDL_SetVideoMode: %s\n", SDL_GetError());
        return -1;
    }
    SDL_WM_SetCaption("SDL1.2 Modular Game", NULL);
    font = TTF_OpenFont("arial.ttf", 24);
    if (!font) {
        fprintf(stderr, "TTF_OpenFont: %s\n", TTF_GetError());
        return -1;
    }
    return 0;
}

void cleanupSDL(void) {
    if (font) TTF_CloseFont(font);
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
}

SDL_Surface* loadImage(const char *file) {
    char path[128];
    snprintf(path, sizeof(path), "assets/%s", file);
    SDL_Surface *tmp = IMG_Load("puzzel.jpg");
    if (!tmp) {
        fprintf(stderr, "IMG_Load(%s): %s\n", path, IMG_GetError());
        return NULL;
    }
    SDL_Surface *img = SDL_DisplayFormatAlpha(tmp);
    SDL_FreeSurface(tmp);
    return img;
}

int loadCharacter(Character *ch) {
    char fname[64];
    snprintf(fname, sizeof(fname), "char_%d_outfit_%d.png", ch->id, ch->outfit);
    ch->sheet = loadImage("2.png");
    if (!ch->sheet) return -1;
    int w = ch->sheet->w / FRAME_COUNT, h = ch->sheet->h;
    for (int i = 0; i < FRAME_COUNT; ++i)
        ch->frames[i] = (SDL_Rect){ i*w, 0, w, h };
    ch->currentFrame = 0;
    ch->x = (ch->id == 1 ? 100 : 600);
    ch->y = 400;
    ch->vx = ch->vy = 0;
    return 0;
}

void freeMedia(Character *ch) {
    if (ch->sheet) SDL_FreeSurface(ch->sheet);
}

int initControllers(void) {
    if (SDL_Init(SDL_INIT_JOYSTICK) < 0) {
        fprintf(stderr, "Failed to initialize SDL Joystick: %s\n", SDL_GetError());
        return 0;
    }
    
    SDL_JoystickEventState(SDL_ENABLE);  // Enable joystick events
    
    int num_joysticks = SDL_NumJoysticks();
    printf("Found %d joysticks\n", num_joysticks);
    
    for (int i = 0; i < num_joysticks && i < MAX_JOYSTICKS; i++) {
        SDL_Joystick *joy = SDL_JoystickOpen(i);
        if (joy) {
            printf("Joystick %d:\n", i);
            printf("  Name: %s\n", SDL_JoystickName(i));
            printf("  Number of Buttons: %d\n", SDL_JoystickNumButtons(joy));
            printf("  Number of Axes: %d\n", SDL_JoystickNumAxes(joy));
            printf("  Number of Balls: %d\n", SDL_JoystickNumBalls(joy));
            printf("  Number of Hats: %d\n", SDL_JoystickNumHats(joy));
        } else {
            fprintf(stderr, "Failed to open joystick %d: %s\n", i, SDL_GetError());
        }
    }
    return num_joysticks;
}

void closeControllers(void) {
    for (int i = 0; i < MAX_JOYSTICKS; i++) {
        if (SDL_JoystickOpened(i)) {
            SDL_JoystickClose(SDL_JoystickOpen(i));
        }
    }
}

void handleControllerInput(Character *p1, Character *p2, int numPlayers) {
    // Handle player 1 controller
    if (p1->joystick && SDL_JoystickOpened(0)) {
        // Map ESP32 BLE gamepad buttons to movement
        // Button mapping matches the ESP32 code:
        // 0 = Up, 1 = Down, 2 = Left, 3 = Right
        // 4 = A, 5 = B, 6 = X, 7 = Y
        bool up = SDL_JoystickGetButton(p1->joystick, 0);
        bool down = SDL_JoystickGetButton(p1->joystick, 1);
        bool left = SDL_JoystickGetButton(p1->joystick, 2);
        bool right = SDL_JoystickGetButton(p1->joystick, 3);
        bool btnA = SDL_JoystickGetButton(p1->joystick, 4);
        bool btnB = SDL_JoystickGetButton(p1->joystick, 5);
        bool btnX = SDL_JoystickGetButton(p1->joystick, 6);
        bool btnY = SDL_JoystickGetButton(p1->joystick, 7);
        
        // Movement
        if (left && !right) {
            p1->vx = -5;
        }
        else if (right && !left) {
            p1->vx = 5;
        }
        else {
            p1->vx = 0;
        }
        
        // Jump (Up button)
        if (up && p1->y >= 400) {
            p1->vy = -15;
        }
        
        // Attack (A button)
        if (btnA) {
            attackPlayer(p1, p2);
        }
        
        // Debug output for button states
        if (up || down || left || right || btnA || btnB || btnX || btnY) {
            printf("P1 Buttons - Up: %d, Down: %d, Left: %d, Right: %d, A: %d, B: %d, X: %d, Y: %d\n",
                   up, down, left, right, btnA, btnB, btnX, btnY);
        }
    }
    
    // Handle player 2 controller
    if (numPlayers == 2 && p2->joystick && SDL_JoystickOpened(1)) {
        bool up = SDL_JoystickGetButton(p2->joystick, 0);
        bool down = SDL_JoystickGetButton(p2->joystick, 1);
        bool left = SDL_JoystickGetButton(p2->joystick, 2);
        bool right = SDL_JoystickGetButton(p2->joystick, 3);
        bool btnA = SDL_JoystickGetButton(p2->joystick, 4);
        bool btnB = SDL_JoystickGetButton(p2->joystick, 5);
        bool btnX = SDL_JoystickGetButton(p2->joystick, 6);
        bool btnY = SDL_JoystickGetButton(p2->joystick, 7);
        
        if (left && !right) {
            p2->vx = -5;
        }
        else if (right && !left) {
            p2->vx = 5;
        }
        else {
            p2->vx = 0;
        }
        
        if (up && p2->y >= 400) {
            p2->vy = -15;
        }
        
        if (btnA) {
            attackPlayer(p2, p1);
        }
    }
}

void handleInput(int *running, Character *p1, Character *p2, int numPlayers) {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        if (e.type == SDL_QUIT) *running = 0;
        else if (e.type == SDL_KEYDOWN) {
            // Joueur 1
            switch (e.key.keysym.sym) {
                case SDLK_ESCAPE: *running = 0; break;
                case SDLK_RIGHT:  p1->vx = 5; break;
                case SDLK_LEFT:   p1->vx = -5; break;
                case SDLK_UP:     if (p1->y>=400) p1->vy = -15; break;
                case SDLK_a:      attackPlayer(p1,p2); break;
                default: break;
            }
            // Joueur 2
            if (numPlayers==2) {
                switch (e.key.keysym.sym) {
                    case SDLK_d:  p2->vx = 5; break;
                    case SDLK_q:  p2->vx = -5; break;
                    case SDLK_w:  if (p2->y>=400) p2->vy = -15; break;
                    case SDLK_s:  attackPlayer(p2,p1); break;
                    default: break;
                }
            }
        }
        else if (e.type == SDL_KEYUP) {
            if (e.key.keysym.sym==SDLK_RIGHT || e.key.keysym.sym==SDLK_LEFT)
                p1->vx = 0;
            if (numPlayers==2 &&
                (e.key.keysym.sym==SDLK_d || e.key.keysym.sym==SDLK_q))
                p2->vx = 0;
        }
    }
    
    // Handle controller input
    handleControllerInput(p1, p2, numPlayers);
}

void attackPlayer(Character *att, Character *vic) {
    int dx = abs(att->x - vic->x), dy = abs(att->y - vic->y);
    if (dx<=ATTACK_RANGE && dy<=ATTACK_RANGE && vic->lives>0) {
        vic->lives--;
        att->score++;
    }
}

void updateCharacter(Character *ch) {
    ch->x += ch->vx;
    ch->vy += 1;
    ch->y += ch->vy;
    if (ch->y>=400) { ch->y=400; ch->vy=0; }
    ch->currentFrame = (ch->currentFrame+1)%FRAME_COUNT;
}

void displayCharacter(SDL_Surface *screen, Character *ch) {
    SDL_Rect dst={ch->x,ch->y,0,0};
    SDL_BlitSurface(ch->sheet,&ch->frames[ch->currentFrame],screen,&dst);
}

void displayHUD(SDL_Surface *screen, Character *ch, int x, int y) {
    char txt[64];
    snprintf(txt,sizeof(txt),"P%d Score:%d Lives:%d",
             ch->id,ch->score,ch->lives);
    SDL_Surface *s = TTF_RenderText_Solid(font,txt,(SDL_Color){255,255,255,255});
    SDL_BlitSurface(s,NULL,screen,&(SDL_Rect){x,y,0,0});
    SDL_FreeSurface(s);
}

void showSubMenu(Character *p1, Character *p2, int numPlayers, SDL_Surface *screen) {
    SDL_Event e;
    p1->id=1; p1->outfit=0;
    p2->id=2; p2->outfit=0;
    int sel=1;
    while(sel) {
        SDL_FillRect(screen,NULL,0);
        SDL_Surface *t = TTF_RenderText_Solid(
            font,"J1:</>/^v perso/tenue | ENTER OK",(SDL_Color){255,255,0,255});
        SDL_BlitSurface(t,NULL,screen,&(SDL_Rect){20,20,0,0}); SDL_FreeSurface(t);
        if(numPlayers==2) {
            t=TTF_RenderText_Solid(
              font,"J2:Q/D perso,W/S tenue",(SDL_Color){255,255,0,255});
            SDL_BlitSurface(t,NULL,screen,&(SDL_Rect){20,60,0,0}); SDL_FreeSurface(t);
        }
        char b1[32],b2[32];
        snprintf(b1,32,"J1->P:%d T:%d",p1->id,p1->outfit);
        t=TTF_RenderText_Solid(font,b1,(SDL_Color){0,255,0,255});
        SDL_BlitSurface(t,NULL,screen,&(SDL_Rect){100,100,0,0}); SDL_FreeSurface(t);
        if(numPlayers==2) {
            snprintf(b2,32,"J2->P:%d T:%d",p2->id,p2->outfit);
            t=TTF_RenderText_Solid(font,b2,(SDL_Color){0,255,0,255});
            SDL_BlitSurface(t,NULL,screen,&(SDL_Rect){100,140,0,0}); SDL_FreeSurface(t);
        }
        SDL_Flip(screen);
        while(SDL_PollEvent(&e)){
            if(e.type==SDL_QUIT) sel=0;
            else if(e.type==SDL_KEYDOWN){
                switch(e.key.keysym.sym){
                    case SDLK_RETURN: sel=0; break;
                    case SDLK_ESCAPE: exit(0);
                    case SDLK_LESS:   p1->id = p1->id>1?p1->id-1:1; break;
                    case SDLK_GREATER:p1->id++; break;
                    case SDLK_UP:     p1->outfit++; break;
                    case SDLK_DOWN:   p1->outfit=p1->outfit>0?p1->outfit-1:0; break;
                }
                if(numPlayers==2){
                    switch(e.key.keysym.sym){
                        case SDLK_q: p2->id=p2->id>1?p2->id-1:1; break;
                        case SDLK_d: p2->id++; break;
                        case SDLK_w: p2->outfit++; break;
                        case SDLK_s: p2->outfit=p2->outfit>0?p2->outfit-1:0; break;
                    }
                }
            }
        }
        SDL_Delay(100);
    }
}

