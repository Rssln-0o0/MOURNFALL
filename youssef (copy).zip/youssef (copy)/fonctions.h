#ifndef FONCTIONS_H
#define FONCTIONS_H

#include "SDL/SDL.h"
#include "SDL/SDL_ttf.h"

#define FRAME_COUNT   4
#define ATTACK_RANGE  50
#define MAX_JOYSTICKS 4

typedef struct {
    int id, outfit;
    SDL_Surface *sheet;
    SDL_Rect frames[FRAME_COUNT];
    int currentFrame;
    int x, y, vx, vy;
    int score, lives;
    SDL_Joystick *joystick;
} Character;

// Initialisation & cleanup SDL
int  initSDL(SDL_Surface **screen);
void cleanupSDL(void);

// Controller support
int initControllers(void);
void closeControllers(void);
void handleControllerInput(Character *p1, Character *p2, int numPlayers);

// Chargement d’image (assets/)
SDL_Surface* loadImage(const char *file);

// Chargement / libération spritesheets
int  loadCharacter(Character *ch);
void freeMedia(Character *ch);

// Entrées & combat
void handleInput(int *running, Character *p1, Character *p2, int numPlayers);
void attackPlayer(Character *attacker, Character *victim);

// Physique & animation
void updateCharacter(Character *ch);

// Affichage sprite & HUD
void displayCharacter(SDL_Surface *screen, Character *ch);
void displayHUD(SDL_Surface *screen, Character *ch, int x, int y);

// Menu de sélection
void showSubMenu(Character *p1, Character *p2, int numPlayers, SDL_Surface *screen);

#endif /* FONCTIONS_H */

