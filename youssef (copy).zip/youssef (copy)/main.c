#include <stdio.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "fonctions.h"

int main(int argc, char* argv[]) {
    SDL_Surface *screen = NULL, *background = NULL;
    Character player1, player2;
    int running = 1, numPlayers = 1;
    int num_controllers = initControllers();
    printf("Connected controllers: %d\n", num_controllers);

    // Choix du mode de jeu
    printf("Mode de jeu (1 = un joueur, 2 = deux joueurs) : ");
    if (scanf("%d", &numPlayers) != 1 || numPlayers != 2) {
        numPlayers = 1;
    }

    // Initialisations
    if (initSDL(&screen) != 0) return 1;

    // Initialize controller connections
    player1.joystick = (num_controllers > 0) ? SDL_JoystickOpen(0) : NULL;
    player2.joystick = (num_controllers > 1) ? SDL_JoystickOpen(1) : NULL;

    // Chargement du fond
    background = loadImage("puzzel.jpg");
    if (!background) return 1;

    // Sélection perso/tenue
    showSubMenu(&player1, &player2, numPlayers, screen);

    // Chargement spritesheets
    if (loadCharacter(&player1) != 0) return 1;
    if (numPlayers == 2 && loadCharacter(&player2) != 0) return 1;

    // Init scores & vies
    player1.score = 0; player1.lives = 3;
    if (numPlayers == 2) { player2.score = 0; player2.lives = 3; }

    // Boucle principale
    while (running) {
        handleInput(&running, &player1, &player2, numPlayers);
        updateCharacter(&player1);
        if (numPlayers == 2) updateCharacter(&player2);

        // Rendu
        SDL_FillRect(screen, NULL, 0);
        SDL_BlitSurface(background, NULL, screen, NULL);
        displayCharacter(screen, &player1);
        if (numPlayers == 2) displayCharacter(screen, &player2);
        displayHUD(screen, &player1, 10, 10);
        if (numPlayers == 2) displayHUD(screen, &player2, 10, 40);
        SDL_Flip(screen);

        SDL_Delay(16);
    }

    // Cleanup
    SDL_FreeSurface(background);
    freeMedia(&player1);
    if (numPlayers == 2) freeMedia(&player2);
    closeControllers();
    cleanupSDL();
    return 0;
}

