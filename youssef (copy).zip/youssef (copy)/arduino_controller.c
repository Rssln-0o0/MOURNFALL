#include "arduino_controller.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

static ArduinoController controller_state = {0};
static int serial_fd = -1;

void arduino_controller_init() {
    // Open serial port (adjust this to your actual serial port)
    serial_fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY);
    if (serial_fd == -1) {
        perror("Failed to open serial port");
        return;
    }

    // Configure serial port
    struct termios options;
    tcgetattr(serial_fd, &options);
    cfsetispeed(&options, B9600);
    cfsetospeed(&options, B9600);
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    options.c_oflag &= ~OPOST;
    tcsetattr(serial_fd, TCSANOW, &options);
}

void arduino_controller_update() {
    if (serial_fd == -1) return;

    char buffer[256];
    int bytes_read = read(serial_fd, buffer, sizeof(buffer) - 1);
    
    if (bytes_read > 0) {
        buffer[bytes_read] = '\0';
        char *line = strtok(buffer, "\n");
        
        while (line != NULL) {
            // Parse button states (format: "1:0:1:0:0")
            if (strchr(line, ':') != NULL) {
                sscanf(line, "%d:%d:%d:%d:%d", 
                    &controller_state.left,
                    &controller_state.right,
                    &controller_state.jump,
                    &controller_state.attack,
                    &controller_state.down);
            }
            // Parse score (format: "S:100" or just "100")
            else if (strstr(line, "S:") == line || isdigit(line[0])) {
                controller_state.score = atoi(strstr(line, "S:") ? line + 2 : line);
            }
            // Parse time (format: "T:120")
            else if (strstr(line, "T:") == line) {
                controller_state.game_time = atoi(line + 2);
            }
            // Parse game state (format: "G:1")
            else if (strstr(line, "G:") == line) {
                controller_state.game_state = atoi(line + 2);
            }
            
            line = strtok(NULL, "\n");
        }
    }
}

void arduino_controller_close() {
    if (serial_fd != -1) {
        close(serial_fd);
        serial_fd = -1;
    }
}

const ArduinoController* arduino_controller_get_state() {
    return &controller_state;
}
